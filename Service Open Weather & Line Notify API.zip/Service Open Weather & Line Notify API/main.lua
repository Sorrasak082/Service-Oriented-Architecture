local widget = require("widget")
local JSON = require("json")
local tableView
local cx,cy
local textLine,butLine
local token = "h8TZHKis9Z0KTMu5X1BjwgFUGH5xPIU3zHKHQc6lfa9"
local www = "http://phuketsmartcity.com/images/rilakkuma/small/"
local image
local widget = require("widget")
local lang = "en"
local resp
local imgIcon,icon
local name, temp, main, desc ,sunrise, sunset


local function numToFileName(num)
	return string.format("%03d", num) ..".png"
end

function sendNotifyListener(event)
	local statuss
	if (event.phase == "ended") then
		print(event.response)
		status = JSON.decode(event.response)["status"]
		errorMessage = JSON.decode(event.response)["message"]

	if (status == 200)then
		txtStatus = display.newText("<< Send Successful >>", cx,505, "WR Tish Kid", 20)
		txtStatus:setFillColor(0.5,0.5,0)

		--imgSuccess = display.newImage("success.png",100,cy+240)

	elseif(status == 400)then
		txtStatus = display.newText("<< Send False !! >>", cx,505, "WR Tish Kid", 20)
		txtError = display.newText("Error : Line Notify doesn't join group",cx,500,"WR Tish Kid", 20)
		txtStatus:setFillColor(1,0,0)
		txtError:setFillColor(1,0,0)
	else
		txtStatus = display.newText("<< Send False !! >>", cx,505, "WR Tish Kid", 20)
		txtError = display.newText("Error : "..errorMessage,cx,505,"WR Tish Kid", 20)
		txtStatus:setFillColor(1,0,0)
		txtError:setFillColor(1,0,0)
	end
end
	
end

function reqSendNotify(message)
local params = {}
local headers = {}

headers["Authorization"] = "Bearer " .. token
headers["Cache-Control"] = "no-cache"
headers["Content-Length"] = string.len(message)
headers["Content-Type"] =  "application/x-www-form-urlencoded; charset=UTF-8"
headers["Host"] = "notify-api.line.me"
headers["User-Agent"] = "Line-BOT"
params.headers = headers

if(image ~= nil)then
	params.body = "message=".. message.."&imageThumbnail="..www..""..image.."&imageFullsize="..www..""..image..""
	if(Bigimage)then
 			Bigimage:removeSelf()
 			Bigimage = nil
 	end	

elseif(images == nil)then
	params.body = "message=".. message
end

if(Bigimage)then
 	Bigimage:removeSelf()
 	Bigimage = nil
 end	
 if(txtStatus)then
 	txtStatus:removeSelf()
 	txtStatus = nil
 end
 if(txtError)then
 	txtError:removeSelf()
 	txtError = nil
 end

 

	if (Bigimage ~= nil)then
		Bigimage.isVisible = false
	elseif (Bigimage == nil)then
		print("")
	end

 if(txtNull)then
 	txtNull:removeSelf()
 	txtNull = nil
 end

network.request(
	"https://notify-api.line.me/api/notify",
	"POST",
	sendNotifyListener,
	params

	)
end

local function updateBigStricker(num)
	image = numToFileName(num)
	Bigimage = display.newImage("/small/" .. image, 200, 400)
	buttonEvent(image)

	--[[if(Bigimage)then
 	Bigimage:removeSelf()
 	Bigimage = nil
 end	]]--

end

local function rowTouch(event)
	--[[if (Bigimage ~= nil)then
		Bigimage.isVisible = false
	elseif (Bigimage == nil)then	
	end]]--

	if(event.phase == "release") then
		updateBigStricker(event.row.index)	
		
	end




end

local function rowRender(event)
	local id = event.row.index
	display.newImage(
		event.row,
		"/small/".. numToFileName(id),
		event.row.contentWidth / 2,
		40
		)

end

function TextListener(event)
	if(event.phase == "ended")then
		textLine.text = ""
		butWeather.isVisible = true
		butText.isVisible = false
	end
end

function WeatherListener(event)
	if(event.phase == "ended")then
		textLine.text = name.text .." - ".. main.text .." - ".. desc.text .." - Temperature : ".. temp.text .."- Sunrise ".. sunrise.text.."- Sunset ".. sunset.text
		butWeather.isVisible = false
		butText.isVisible = true
	end
end

function buttonEvent(event)
	if (event.phase == "ended") then
	
		if (textLine.text ~= "") then
			reqSendNotify(textLine.text)
		else
			txtNull = display.newText("Please Message !!",cx,505,"WR Tish Kid", 20)
			txtNull:setFillColor(0,0,0)
		end

		if(Bigimage)then
 			Bigimage:removeSelf()
 			Bigimage = nil
 		end	

 		if(txtStatus)then
 			txtStatus:removeSelf()
 			txtStatus = nil
 		end
		textLine.text = ""
	end
end



function buttonOKEvent(event)
	if (event.phase == "ended") then

	if (textToken.text ~= "") then
		token = textToken.text
		tableView.isVisible = true
		textLine.isVisible = true
		butLine.isVisible = true
		ButChange.isVisible = true
		textToken.isVisible = false
		butOk.isVisible = false
		butBack.isVisible = false
		txt.isVisible = false
		txtRegis.isVisible = false
		Background.isVisible = true
		display.setDefault("background",1,1,1)
	end
		textToken.text = ""
		
	end
end

function buttonBackEvent(event)
	if (event.phase == "ended") then
		tableView.isVisible = true
		textLine.isVisible = true
		butLine.isVisible = true
		ButChange.isVisible = true
		name.isVisible = true
		temp.isVisible = true
		main.isVisible = true
		desc.isVisible = true
		imgIcon.isVisible = true
		textToken.isVisible = false
		butOk.isVisible = false
		butBack.isVisible = false
		txt.isVisible = false
		txtRegis.isVisible = false
		butText.isVisible = true
		butWeather.isVisible = true
		butSearch.isVisible = true
		display.setDefault("background",1,1,1)
		Background.isVisible = true
	end
end

local function ChangeListener(event)
		if(event.phase == "ended")then
			tableView.isVisible = false
			textLine.isVisible = false
			butLine.isVisible = false
			ButChange.isVisible = false
			name.isVisible = false
			temp.isVisible = false
			main.isVisible = false
			desc.isVisible = false
			imgIcon.isVisible = false
			textToken.isVisible = true
			butOk.isVisible = true
			butBack.isVisible = true
			txt.isVisible = true
			txtRegis.isVisible = true
			butText.isVisible = false
			butWeather.isVisible = false
			butSearch.isVisible = false
			display.setDefault("background",0,0.75,0.4)
			Background.isVisible = false
		if(txtStatus)then
 			txtStatus:removeSelf()
 			txtStatus = nil
 		end

 		if(txtError)then
 			txtError:removeSelf()
 			txtError = nil
 		end

		if (Bigimage ~= nil)then
			Bigimage.isVisible = false
		elseif (Bigimage == nil)then
			print("")
		end
		
		if(txtNull)then
 			txtNull:removeSelf()
 			txtNull = nil
 		end
	end
end

local function CreateTokenListener(event)
		if(event.phase == "ended")then
			system.openURL( "https://notify-bot.line.me/th/" )	
		end
	end

tableView = widget.newTableView
{
	left = 10,
	top = 80,
	height = 340,
	width = 100,
	onRowRender = rowRender,
	onRowTouch = rowTouch



}
for i = 1, 23 do
	tableView:insertRow(
	{
		isCategory = false,
		rowHeight = 85,
		rowColor = {defult = {0.5,0.5,0.5}, over = {0.5,0.5,0.5}},
		lineColor = {1,1,1}
}
		)

	end

cx = display.contentCenterX
cy = display.contentCenterY
display.setDefault("background",1,1,1)


Background = display.newImage("bg.png",160,5)
ButChange = display.newImage("chang.png",290,0)
butSearch = display.newImage("search.png",cx+130,cy+230)
butText = display.newImage("text.png",cx+130,cy-160)
butWeather = display.newImage("weather.png",cx+130,cy-160)




textToken = native.newTextField( cx, cy, 300, 40)
textToken.align = "center"
textToken.isVisible = false
txt = display.newText("Please Token ID",cx,150,"WR Tish Kid", 50)
txt:setFillColor(1,0,0)

txtRegis = display.newText("Create Token ID",cx,470,"WR Tish Kid", 30)
txtRegis:setFillColor(0,0,1)



butLine = widget.newButton(
		    {
		        x = cx+70, y = cy+230,
		        onEvent = buttonEvent,
		        defaultFile = "line.png"
		       	         
		    }
		    
		)



butOk = widget.newButton(
		    {
		        x = cx, y = cy+100,
		        onEvent = buttonOKEvent,
		        defaultFile = "ok.png"
		       	         
		    }
		    
		)

butBack = widget.newButton(
		    {
		        x = 290, y = 0,
		        onEvent = buttonBackEvent,
		        defaultFile = "back.png"
		       	         
		    }
		    
		)

butText.isVisible = false
butOk.isVisible = false
butBack.isVisible = false
txt.isVisible = false
txtRegis.isVisible = false

ButChange:addEventListener("touch",ChangeListener)
txtRegis:addEventListener("touch",CreateTokenListener)
butText:addEventListener("touch",TextListener)
butWeather:addEventListener("touch",WeatherListener)


--------------------------------------------Weather API-----------------------------------------------------

local function handleResponse(event)
	resp =JSON.decode(event.response)
	if not (event.isError) then
	
	sunriseTime = os.date("%X", resp["sys"]["sunrise"])
	sunsetTime = os.date("%X", resp["sys"]["sunset"])

	name = display.newText("name", cx+50, 240, "WR Tish Kid", 50) 
	temp = display.newText("temp", cx+50, 350, "WR Tish Kid", 50)
	main = display.newText("main", cx+50, 280, "WR Tish Kid", 40)  
	desc = display.newText("dese", cx+50, 310, "WR Tish Kid", 25) 
	sunrise = display.newText("sunrise", 180, 445, "FunintheJungle", 1)
	sunset = display.newText("sunset", 180, 485, "FunintheJungle", 1)
	
	name:setFillColor(0,0,0)
	temp:setFillColor(0,0,0)
	main:setFillColor(0,0,0)
	desc:setFillColor(0,0,0)
	
	
		name.text = resp["name"]
		temp.text = resp["main"]["temp"].."C"
		main.text = resp["weather"][1]["main"]
		desc.text = resp["weather"][1]["description"]
	   	sunrise.text = sunriseTime
	   	sunset.text = sunsetTime
	    --wind.text = resp["wind"]["speed"]
	    --tempmin.text = resp["main"]["temp_min"].."°C"
	    --tempmax.text = resp["main"]["temp_max"].."°C"
	    --humidity.text = resp["main"]["humidity"].."%"
		icon = resp["weather"][1]["icon"]
		if (imgIcon)then
			imgIcon:removeSelf()
			imgIcon = nil
		end
		
		soundEffect = audio.loadSound("sounds/"..icon..".mp3")
		audio.play(soundEffect)
		
		
		imgIcon = display.newImage("images/"..icon..".png",cx+50,140)
		imgIcon:scale(1,1)

		
	end
	

end
print(icon)
local  function loadWeather()
	--local cid = province_id[id]
	network.request(
	"http://api.openweathermap.org/data/2.5/weather?q="..cid.."&appid=645d8af0a1000ec623890f0aa044ca45&units=metric",
	"GET",
	handleResponse

	)
end	
local function SearchListener(event)
		if(event.phase == "ended")then
		cid = textLine.text
			name.isVisible = false
			temp.isVisible = false
			main.isVisible = false
			desc.isVisible = false
			imgIcon.isVisible = false
			audio.pause(soundEffect)
		loadWeather()
		textLine.text = ""
	end

end


cid = "Phuket"
id = 1

--background = display.setDefault("background", 0.3,0.3,0.3)
cx = display.contentCenterX
cy = display.contentCenterY

textLine = native.newTextField( cx-60, cy+230, 180, 50 )
textLine.align = "center"
butSearch:addEventListener("touch",SearchListener)
loadWeather()